package com.example.demoSpringBootCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBootCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootCrudApplication.class, args);
	}

}
