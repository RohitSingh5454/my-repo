package com.example.uploadImage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadImageApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadImageApplication.class, args);
	}

}
