package com.example.uploadImage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadImageApplicationTests {

	@Test
	void contextLoads() {
	}

}
