package com.example.OaathImplementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OaathImplementationApplicationTests {

	@Test
	void contextLoads() {
	}

}
