package com.example.zoneWiseData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoneWiseDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoneWiseDataApplication.class, args);
	}

}
