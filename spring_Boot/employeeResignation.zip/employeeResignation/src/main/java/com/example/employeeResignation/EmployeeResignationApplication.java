package com.example.employeeResignation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeResignationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeResignationApplication.class, args);
	}

}
