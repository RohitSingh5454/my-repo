package com.example.saveList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveListApplicationTests {

	@Test
	void contextLoads() {
	}

}
