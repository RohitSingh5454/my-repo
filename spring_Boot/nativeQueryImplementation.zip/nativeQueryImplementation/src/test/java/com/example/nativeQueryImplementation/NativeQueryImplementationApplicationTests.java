package com.example.nativeQueryImplementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NativeQueryImplementationApplicationTests {

	@Test
	void contextLoads() {
	}

}
