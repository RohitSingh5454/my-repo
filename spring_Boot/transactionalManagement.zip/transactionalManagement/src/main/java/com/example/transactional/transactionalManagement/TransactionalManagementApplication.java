package com.example.transactional.transactionalManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionalManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionalManagementApplication.class, args);
	}

}
